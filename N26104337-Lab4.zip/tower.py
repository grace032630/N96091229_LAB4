import pygame
import os
import math
from settings import WIN_WIDTH, WIN_HEIGHT

TOWER_IMAGE = pygame.image.load(os.path.join("images", "rapid_test.png"))


class Circle:
    def __init__(self, center, radius):
        self.center = center
        self.radius = radius

    def collide(self, enemy):
        
        enemy_x, enemy_y = enemy.rect.center                                #define enemy's position
        attack_x, attack_y = self.center                                    #define position of center
        dis = math.sqrt((attack_x - enemy_x)**2 + (attack_y - enemy_y)**2)  #find the range between enemy and circle
        if dis <= self.radius:                                              #if in attack range
            return True                                                     #if in range return true
        else:
            return False                                                    #if out of range return false
        """
        Q2.2)check whether the enemy is in the circle (attack range), if the enemy is in range return True
        :param enemy: Enemy() object
        :return: Bool
        """

        """
        Hint:
        x1, y1 = enemy.get_pos()
        ...
        """
        pass

    def draw_transparent(self, win):
        # create transparent surface
        transparent_surface = pygame.Surface((WIN_WIDTH, WIN_HEIGHT), pygame.SRCALPHA)
        transparency = 100  # define transparency: 0~255, 0 is fully transparent
        # draw the circle on the transparent surface
        pygame.draw.circle(transparent_surface, (125, 125, 125, transparency),self.center,self.radius)
        win.blit(transparent_surface, (0, 0))
        """
        Q1) draw the tower effect range, which is a transparent circle.
        :param win: window surface
        :return: None
        """
        pass


class Tower:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(TOWER_IMAGE, (70, 70))  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)                                   # center of the tower
        self.range = 150                                            # tower attack range
        self.damage = 2                                             # tower damage
        self.range_circle = Circle(self.rect.center, self.range)    # attack range circle (class Circle())
        self.cd_count = 0                                           # used in self.is_cool_down()
        self.cd_max_count = 60                                      # used in self.is_cool_down()
        self.is_selected = True                                     # the state of whether the tower is selected
        self.type = "tower"

    def is_cool_down(self):
        #if self.cd_count smaller than max_count
        if self.cd_count < self.cd_max_count:
            self.cd_count += 1                  #counter+1
            return False                        #out of condition return false
        else:
            self.cd_count = 0                   #counter return to zero
            return True                         #is cool down
        """
        Q2.1) Return whether the tower is cooling down
        (1) Use a counter to computer whether the tower is cooling down (( self.cd_count
        :return: Bool
        """

        """
        Hint:
        let counter be 0
        if the counter < max counter then
            set counter to counter + 1
        else 
            counter return to zero
        end if
        """
        pass

    def attack(self, enemy_group):
        if self.is_cool_down():                       #if tower is cool down
            for en in enemy_group.get():              #to get enemy in loop
                if self.range_circle.collide(en):     #if enemy in attack range
                    en.get_hurt(self.damage)          #attack enemy
                    break                             #this break make sure you just attack the first one enemy in attack range
        """
        Q2.3) Attack the enemy.
        (1) check the the tower is cool down ((self.is_cool_down()
        (2) if the enemy is in attack range, then enemy get hurt. ((Circle.collide(), enemy.get_hurt()
        :param enemy_group: EnemyGroup()
        :return: None
        """
        pass

    def is_clicked(self, x, y):
        """
        Bonus) Return whether the tower is clicked
        (1) If the mouse position is on the tower image, return True
        :param x: mouse pos x
        :param y: mouse pos y
        :return: Bool
        """
        #to limit x in image's left and right boundary
        #to limit y in image's top and bottom boundary
        if self.rect.midleft[0] <= x <= self.rect.midright[0] and self.rect.midtop[1] <= y <= self.rect.midbottom[1]:
            return True         #if in range return true
        else:
            return False        #if out of range return false
        pass

    def get_selected(self, is_selected):
        """
        Bonus) Change the attribute self.is_selected
        :param is_selected: Bool
        :return: None
        """
        self.is_selected = is_selected

    def draw(self, win):
        """
        Draw the tower and the range circle
        :param win:
        :return:
        """
        # draw range circle
        if self.is_selected:
            self.range_circle.draw_transparent(win)
        # draw tower
        win.blit(self.image, self.rect)


class TowerGroup:
    def __init__(self):
        self.constructed_tower = [Tower(250, 380), Tower(420, 400), Tower(600, 400)]

    def get(self):
        return self.constructed_tower

